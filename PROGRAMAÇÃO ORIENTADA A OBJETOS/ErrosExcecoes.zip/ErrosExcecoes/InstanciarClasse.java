package errosexcecoes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class InstanciarClasse {

  public static void main(String[] args) {
    try {
      //BufferedReader br = new BufferedReader( new InputStreamReader( System.in ) );
      BufferedReader br = new BufferedReader( new FileReader( "teste" ) );

      System.out.print("Digite o nome da classe: ");
      String s = br.readLine();
      Class c = Class.forName( s );
      System.out.println( "Conseguiu instanciar Class: " + c );

    } catch (ClassNotFoundException e) {
      System.err.println("catch 1");
      e.printStackTrace();

    } catch (IOException e) {
      System.err.println("catch 2");
      e.printStackTrace();
    }
  }
}
