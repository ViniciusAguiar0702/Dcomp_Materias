package swing;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class GridBagLayoutDemo extends JFrame {

  public GridBagLayoutDemo() {

    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints c = new GridBagConstraints();
    getContentPane().setLayout(gridbag);

    // Os componentes podem ser esticados nas duas direções
    // para ocupar todo o espaço disponível
    c.fill = GridBagConstraints.BOTH;
    c.weightx = 1.0;
    criarButton("Button1", gridbag, c);
    criarButton("Button2", gridbag, c);
    criarButton("Button3", gridbag, c);

    c.gridwidth = GridBagConstraints.REMAINDER; // Fim da linha
    criarButton("Button4", gridbag, c);

    c.weightx = 0.0;                      // Volta ao padrão
    criarButton("Button5", gridbag, c);   // Outra linha

    c.gridwidth = GridBagConstraints.RELATIVE;
    criarButton("Button6", gridbag, c);

    c.gridwidth = GridBagConstraints.REMAINDER; // Fim da linha
    criarButton("Button7", gridbag, c);

    c.gridwidth = 1;    // Volta ao padrão
    c.gridheight = 2;   // Ocupa duas células na vertical
    c.weighty = 1.0;    // Especifica a distribuição do espaço
                        // vertical
    criarButton("Button8", gridbag, c);

    c.weighty = 0.0;                   // Volta ao padrão
    c.gridwidth = GridBagConstraints.REMAINDER; // Fim da linha
    c.gridheight = 1;                  // Volta ao padrão
    criarButton("Button9", gridbag, c);
    criarButton("Button10", gridbag, c);

    c.fill = GridBagConstraints.NONE;
    c.anchor = GridBagConstraints.NORTHEAST; // Coloca o componente no nordeste
    c.ipadx = 20; // Espaço dentro do componente acima e abaixo
    c.ipady = 40; // Espaço dentro do componente esquerda e direita
    c.insets = new Insets( 5,  // Acima por fora
                          10,  // à esquerda por fora
                          25,  // Abaixo por fora
                          10); // à direita por fora
    c.gridy = 6;   // Linha 6 (inicia com 0)
    criarButton("Button11", gridbag, c);

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }

  protected void criarButton(String nome,
                             GridBagLayout gridbag,
                             GridBagConstraints c) {
    JButton b = new JButton(nome);
    gridbag.setConstraints(b, c);
    getContentPane().add(b);
  }

  public static void main(String args[]) {
    SwingUtilities.invokeLater (new Runnable () {
		   public void run() { 
			   JFrame f = new GridBagLayoutDemo();
			   f.setTitle("GridBagLayoutDemo");
			   f.pack();
			   f.setVisible(true);
			}
	   });
  }
}
