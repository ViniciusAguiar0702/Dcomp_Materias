package swing;

import java.awt.BorderLayout;
import java.awt.Container;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class BorderLayoutDemo extends JFrame {

  public BorderLayoutDemo() {
    Container contentPane = getContentPane();

    contentPane.add(BorderLayout.NORTH,  new JButton("Norte"));
    contentPane.add(BorderLayout.SOUTH,  new JButton("Sul"));
    contentPane.add(BorderLayout.EAST,   new JButton("Leste"));
    contentPane.add(BorderLayout.WEST,   new JButton("Oeste"));
    contentPane.add(BorderLayout.CENTER, new JButton("Centro"));

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }

  public static void main(String args[]) {

    
    SwingUtilities.invokeLater (new Runnable () {
		   public void run() { 
			   JFrame f = new BorderLayoutDemo();
			   f.setTitle("BorderLayoutDemo");
			   f.pack();
			   f.setVisible(true);
			}
	   });
  }
}