package swing;

import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class JButtonDemo extends JFrame {
  private JButton b1, b2, b3;

  public JButtonDemo() {
    super( "JButton Demo" );

    Container contentPane = getContentPane();
    contentPane.setLayout( new FlowLayout() );

    b1 = new JButton();
    b1.setText("Desabilitar botão do meio");

    Icon icone = new ImageIcon("javalogo.gif");
    b2 = new JButton("Botão do meio", icone);

    b3 = new JButton("Habilitar botão do meio");
    b3.setEnabled( false );

    contentPane.add( b1 );
    contentPane.add( b2 );
    contentPane.add( b3 );

    b1.addActionListener( new Botao1Listener() );
    b3.addActionListener( new Botao3Listener() );

    pack();
    
    this.setVisible(true);
  }

  private class Botao1Listener implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      b2.setEnabled(false);
      b1.setEnabled(false);
      b3.setEnabled(true);
    }
  }

  private class Botao3Listener implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      b2.setEnabled(true);
      b1.setEnabled(true);
      b3.setEnabled(false);
    }
  }

  public static void main( String args[] ) {
	  SwingUtilities.invokeLater (new Runnable () {
		   public void run() { 
			   JButtonDemo application = new JButtonDemo();
			   application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
			}
	   });
  }
}